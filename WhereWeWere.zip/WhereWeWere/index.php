<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="indexstyle.css">
</head>
<body style="background-color:#CCC">
<!-- Simple index: create button and last of all events -->
<table style="width:100%;height:600px;text-align:center">
	<tr>
		<th style="width:45%">
			<!-- Button to create an event -->
			<form action="create.html">
				<input type="submit" value="Make Event" style="float:right;border-radius:5px;padding-right:10px;font:12px openSansReg">
			</form>
		</th>
		<th style="width:10%"></th>
		<th style="width:45%">
			<?php
				$conn = new PDO("mysql:host=127.0.0.1;dbname=whatpzcp_wherewewere","root","");
				$stmt = $conn -> prepare("SELECT `id`, `Title`
				FROM `events` ORDER BY `id` DESC");
				$stmt -> execute();
				$events = $stmt -> fetchAll();
			?>
			<!-- Write all event titles as hyperlinks to their info/messages -->
			<text style="float:left;height:400px;padding-left:10px;overflow-y:auto">
				<?php
					foreach($events as $event) {
						$eventID = $event['id'];
						$title = $event['Title'];
						print "<a href='event.php?id=$eventID'>$title</a>";
						print "</br>";
					}
				?>
			</text>
		</th>
	</tr>
</table>

</body>
</html>
