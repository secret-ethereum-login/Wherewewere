<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="indexstyle.css">
</head>
<body style="background-color:#CCC">

<table style="width:100%;height:600px;text-align:center">
	
	<tr style="height:20%">
	</tr>
	<tr>
		<td>
			<form action="index.html">
					<input type="submit" value="Go Home" style="font:10px openSansReg;border-radius:5px">
			</form>
		</td>
	</tr>
	<tr>
		<td>
			<?php
			$title = $_GET['title'];
			$description = $_GET['description'];
			$place = $_GET['place'];
			$date = $_GET['date'];
			$startTime = $_GET['startTime'];
			$endTime = $_GET['endTime'];
			
			$fullInfo = "$title $description taking place at $place on $date from $startTime to $endTime";

			echo "<img src='createQr.php?fullInfo=$fullInfo' style='border-radius:5px'>";
		?>
		</td>
	</tr>
	<tr>
		<td>
			<p>Title:</p>
			 <?php echo $title ?>
		</td>
	</tr>
	<tr>
		<td>
			<p>Description:</p>
			 <?php echo $description ?>
		</td>
	</tr>
	<tr>
		<td>
			<p>Place:</p>
			 <?php echo $place ?>
		</td>
	</tr>
	<tr>
		<td>
			<p>Date:</p>
			 <?php echo $date ?>
		</td>
	</tr>
	<tr>
		<td>
			<p>T	ime:</p>
			 <?php echo $startTime . " to " . $endTime ?>
		</td>
	</tr>
	<tr>
		<td></td>
	</tr>
	<tr style="height:20%"></tr>
</table>

</body>
</html>
